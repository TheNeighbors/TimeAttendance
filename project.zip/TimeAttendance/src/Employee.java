import java.util.Date;
import java.util.Scanner;

public class Employee {
	

	public static void main(String[] args) {
		ConnectDB con = new ConnectDB();
		//connect db
			con.Connect();
		con.login();
		
		//disconnect
		
		
		
		
		
		
		
		

		// con.checkPassWord();
		// conDB.preStatement();
		// scanner.nextLine();
		//System.out.println(date);

	}
}
